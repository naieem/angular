<?php

/**
 * ILC Tabbed Functions
 */

if ( is_admin() ) require_once( TEMPLATEPATH . '/settings.php' );

?>